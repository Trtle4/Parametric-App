# Packaging Design Tool

Parametric packaging design tool. Generates dielines, 3D folded views, and machine-ready
cut files across a full packaging hierarchy. Inspired by ArtiosCAD, deliberately narrower
in scope.

Author is a practicing packaging engineer. Domain correctness matters more than clever code.

---

## Long-term architecture

The tool models a **packaging hierarchy**, not a box. Levels, outermost to innermost:

| Level | Name | Example |
|---|---|---|
| 4 | Pallet / unit load | 48 x 40 GMA pallet, stacked, stretch-wrapped |
| 3 | Tertiary / shipper | FEFCO 201 RSC corrugated case |
| 2 | Secondary / carton | Folding carton, tray, wrap |
| 1 | Primary | Bag, pouch, tub, tube — direct product contact |
| 0 | Product | The thing itself |

**These are all the same relationship.** A parent contains N children arranged in a pattern,
with clearances and orientation constraints. Pallet-holds-cases, case-holds-cartons,
carton-holds-primaries, primary-holds-product are one abstraction, instantiated four times.
Do not write per-level bespoke logic where the shared model applies.

Real packaging is designed **bottom-up** (product dictates primary, primary count dictates
carton, and so on) even though this codebase was built top-down. The containment model must
support dimension propagation in **both directions**: solve a parent from its children, and
check children against a fixed parent.

---

## Core principles

**Single source of truth.** A style is defined once, as a pure function. The 2D dieline, the
3D fold, the DXF export, and the packing solver all consume the *same* geometry object.
They never recompute it. If they disagree, the model is wrong, not the renderer.

**Styles are pure functions.** A style takes parameters in, returns geometry out. It reads
nothing from the DOM, touches no globals, and knows nothing about SVG, Three.js, or DXF.
Signature shape: `(params) -> Geometry`.

**Renderers are pure consumers.** 2D / 3D / DXF / packing take a `Geometry` and produce
output. They contain no packaging math.

**Internal units are millimeters. Always.** Every value in the geometry core, the packer,
and the export layer is mm. Unit conversion happens only at the UI boundary, on read and on
display. Never thread a "current unit" flag through the core.

**Compensation belongs to the style.** Inside-to-outside dimensional conversion (board
caliper, flap stack-up, tolerance) is packaging domain knowledge and it lives in the style
module. A style must report its own outside dimensions. Consumers never derive outside dims
by adding caliper themselves.

**No magic numbers.** Any dimensional constant is a named parameter with a comment stating
its packaging rationale. `H + 4*t` is not acceptable; `H + flapStackUp(t)` with an
explanation is.

---

## Output requirements

DXF export must remain machine-ready for a **Kongsberg** cutting table:
- Separate layers, at minimum `CUT` and `CREASE`. Tools are mapped by layer downstream.
- Future layers: `PERF`, `BLEED`, `SCORE_HALF`, `REGISTER`.
- `$INSUNITS` header set correctly.
- Never merge cut and crease geometry into a single layer.

---

## Stack and constraints

- Vanilla ES modules today. Any migration to a framework or build tool is a **separate,
  explicit task** — do not introduce one opportunistically mid-task.
- Three.js for 3D. Plain SVG for the dieline. No canvas rendering of the dieline.
- Geometry core must be framework-agnostic and unit-testable with no DOM.

---

## Working agreements

- **Refactors change structure, not behavior.** If a task says refactor, output must be
  functionally identical. Capture golden values before, verify after.
- **One level of the hierarchy at a time.** Do not speculatively build abstractions for
  levels that have not been requested.
- Do not invent packaging conventions. If a FEFCO/ECMA geometry detail is ambiguous, stop
  and ask rather than guessing — a wrong dieline is worse than no dieline.
- Prefer explicit, readable geometry math over compact math. This code gets audited by a
  packaging engineer, not a JS reviewer.
- No em dashes in any user-facing copy or comments.
