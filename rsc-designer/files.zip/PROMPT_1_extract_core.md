# Prompt 1: Extract the geometry core

Paste this into Claude Code. Do not combine it with Prompt 2.

---

Refactor the single-file app into ES modules with a clean geometry core. This is a
**pure refactor: no new features, no visual changes, no behavior changes.** The app must
look and behave identically when you are done.

## Step 0 — Capture golden values first

Before changing anything, write `test/golden.json` recording current outputs for these
input sets, so we can prove the refactor changed nothing:

- L=200 W=150 H=120, caliper=3, glue=35, slot=6, mm
- L=400 W=300 H=250, caliper=5, glue=50, slot=8, mm
- L=8 W=6 H=5, caliper=0.125, glue=1.5, slot=0.25, inches

For each, record: the full `cut` point array, the `crease` array, flap depth F, blank
bounding box, and the pallet result (pattern label, per-layer count, layers, total,
coverage) for a 48x40 pallet at 60in max height, for all three stack patterns.

## Step 1 — Convert internal math to millimeters only

Right now `unit` is a global that leaks into `geometry()`, `draw2d()`, `exportDXF()`,
`palParams()`, and the `mm()` helper inside `buildPallet()`. Remove that leak.

- The core operates in mm. Period.
- Conversion happens only when reading inputs and when formatting display strings.
- Delete the `mm()` helper in `buildPallet()` and the `palUnit` / `unit` cross-conversion
  logic in `palParams()`. Pallet dimensions convert to mm on read like everything else.

## Step 2 — Module structure

Split `index.html` into:

```
src/
  core/
    types.js          // shared shapes, documented below
    units.js          // mm <-> in conversion, formatting
    styles/
      fefco201.js     // the RSC style, moved out of geometry()
    pack.js           // the layer-fit solver, moved out of buildPallet()
  render/
    dieline2d.js      // draw2d()
    fold3d.js         // init3d/buildBox/applyFold/roundedBoxGeo
    pallet3d.js       // the pallet timber + instanced box rendering
  export/
    dxf.js            // exportDXF()
  ui/
    inputs.js         // the ONLY module that touches the DOM for params
    app.js            // wiring, view switching
index.html            // markup + module entry only
```

## Step 3 — Kill `P()` reading the DOM

`P()` currently reads input elements and is called independently by the 2D renderer, the 3D
builder, the DXF exporter, and the palletizer. Replace it:

- `ui/inputs.js` reads the DOM once, converts to mm, and produces a plain `Params` object.
- That object is passed down explicitly. **No module below `ui/` may touch `document` for
  parameters.**

## Step 4 — Move compensation into the style (important)

`buildPallet()` currently computes outside dimensions inline:

```js
const ol = p.L + 2*t, ow = p.W + 2*t, oh = p.H + 4*t;
```

This is material compensation and it does not belong in the palletizer. The `4*t` is
undocumented flap stack-up.

Make `fefco201.js` return outside dimensions as part of its output, with the stack-up math
named and commented (why 2t on the sides, why 2t top and 2t bottom from doubled flaps).
The packer must consume `geometry.outer` and never add caliper itself.

## Step 5 — Define the types

In `core/types.js`, document these shapes as JSDoc typedefs:

```js
/**
 * @typedef {Object} Params        // all lengths in mm
 * @property {number} L @property {number} W @property {number} H
 * @property {number} caliper @property {number} glue @property {number} slot
 */

/**
 * @typedef {Object} Geometry      // what every style returns
 * @property {[number,number][]} cut      // ordered closed perimeter
 * @property {Segment[]} crease
 * @property {BBox} bbox                  // blank extents
 * @property {Dims} inner                 // internal L/W/H, the usable cavity
 * @property {Dims} outer                 // external L/W/H, compensated
 * @property {Object} meta                // style id, panel landmarks, flap depth
 */
```

Every future style implements this same contract. Do not add fields specific to 201.

## Step 6 — Generalize the packer's signature only

Move `colGrid()` and `mixed()` into `core/pack.js`. Do **not** redesign the algorithm yet.
Just change the signature so it stops being pallet-specific:

```js
packLayer({ childL, childW, parentL, parentW, pattern }) -> { positions, perLayer, label }
stack({ perLayer, childH, parentMaxH, baseH }) -> { layers, total, loadHeight }
```

`pallet3d.js` becomes one caller of these, passing pallet deck size as parent and the case
outer dims as child. The functions must have no knowledge of pallets, boxes, or timber.

## Verify

Run against `test/golden.json`. Every value must match exactly. Report any that do not
rather than adjusting the golden file. Confirm all three views and DXF export still work in
the browser, then commit.
